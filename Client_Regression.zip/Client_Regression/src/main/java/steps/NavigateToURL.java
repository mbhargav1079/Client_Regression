package steps;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import dataProviders.ConfigFileReader;
import drivers.SetupDriver;



public class NavigateToURL {

	public WebDriver driver;

	SetupDriver setupDriver;
	ConfigFileReader configFileReader;
	
	public NavigateToURL(WebDriver driver) {
		 this.driver=driver;
		 PageFactory.initElements(driver, this);
	 }
	
	public WebDriver getAppURL()  {
		
		configFileReader= new ConfigFileReader();
		String appUrl= configFileReader.getApplicationUrl();
		String browserName= configFileReader.getBroswerName();
		
		setupDriver= new SetupDriver(driver);
		driver=setupDriver.getDriver(browserName);
		
		driver.get(appUrl);
		
		driver.manage().window().maximize();
		return driver;
		
	}
	
	
}
