package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import drivers.CRConstants;

public class Login_Page extends Base_Page {

	public WebDriver driver;

	@FindBy(xpath = CRConstants.USER_NAME) WebElement userName;
	@FindBy(xpath = CRConstants.PASSWORD) WebElement password;
	@FindBy(xpath = CRConstants.LOGIN) WebElement login;

	public Login_Page(WebDriver driver) {
		super(driver);
	}

	public WebDriver loginStep(String userNameStr, String passwordStr) {

		this.sendWebElements(userName, userNameStr);
		this.sendWebElements(password, passwordStr);
		this.webEleClick(login);
		
		return driver;
	}
}
