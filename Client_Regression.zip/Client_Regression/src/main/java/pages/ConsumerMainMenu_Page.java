package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import drivers.CRConstants;

public class ConsumerMainMenu_Page extends Base_Page {
	
	public WebDriver driver;
	@FindBy(xpath = CRConstants.CONSUMER_MAIN_MENU) WebElement CONSUMER_MAIN_MENU;
	@FindBy(xpath = CRConstants.DOCUMENTED_DISABILITIES) WebElement DOCUMENTED_DISABILITIES;
	@FindBy(xpath = CRConstants.CONSUMER_MENU_LIST) WebElement CONSUMER_MENU_LIST;
	@FindBy(xpath = CRConstants.DISABILITIES_TYPE_DROPDOWN) WebElement DISABILITIES_TYPE_DROPDOWN;
	@FindBy(xpath = CRConstants.FUNCTIONAL_LIMITATIONS) WebElement FUNCTIONAL_LIMITATIONS;
	@FindBy(xpath = CRConstants.FUNCTIONAL_LIMITATIONS_ROWS) List<WebElement> FUNCTIONAL_LIMITATIONS_ROWS;
	@FindBy(xpath = CRConstants.ASSIGN_TO_DIAGNOSIS) WebElement ASSIGN_TO_DIAGNOSIS;
	@FindBy(xpath = CRConstants.EVALUATION_REPORT) WebElement EVALUATION_REPORT;
	@FindBy(xpath = CRConstants.ER_FIRSTNAME) WebElement ER_FIRSTNAME;
	@FindBy(xpath = CRConstants.ER_TITLE) WebElement ER_TITLE;
	@FindBy(xpath = CRConstants.ER_TITLE_DROPDOWN) WebElement ER_TITLE_DROPDOWN;
	@FindBy(xpath = CRConstants.ER_TITLE_DATEREPORT) WebElement ER_TITLE_DATEREPORT;
	@FindBy(xpath = CRConstants.ER_TODAY) WebElement ER_TODAY;
	@FindBy(xpath = CRConstants.ER_SAVE) WebElement ER_SAVE;
	@FindBy(xpath = CRConstants.ETIOLOGY_SELECT) WebElement ETIOLOGY_SELECT;
	@FindBy(xpath = CRConstants.ETIOLOGY_TYPE) WebElement ETIOLOGY_TYPE;
	@FindBy(xpath = CRConstants.EIOLOGY_ASSIGN) WebElement EIOLOGY_ASSIGN;
	@FindBy(xpath = CRConstants.EIOLOGY_FINALSAVE) WebElement EIOLOGY_FINALSAVE;
	
	
	public ConsumerMainMenu_Page(WebDriver driver) {
		super(driver);
	}
	
	public void FLClick(String text, String FL1, String FL2, String FL3, String FLName) {
		
		if (text.equalsIgnoreCase(FLName) && FL1.equalsIgnoreCase(FLName)
				|| (text.equalsIgnoreCase(FLName) && FL2.equalsIgnoreCase(FLName))
				|| (text.equalsIgnoreCase(FLName) && FL3.equalsIgnoreCase(FLName))) {
			driver.findElement(By.xpath("//label[contains(text(),'" + FLName + "')]")).click();
		}
		
	}
	
	public void evaluationType(String typeOFEvaluationStr, String evaluationValue) {
		Select se = new Select(ER_TITLE_DROPDOWN);
		if (typeOFEvaluationStr.equalsIgnoreCase(evaluationValue)) {
			se.selectByValue(evaluationValue);}
	}
	
	public WebDriver consumer_Documented_Disabilities_Steps( String disabilityNameStr, String FL1Str, String FL2Str, String FL3Str) {
		
		this.webEleClick(CONSUMER_MAIN_MENU);
		this.checkListEleValues(CONSUMER_MENU_LIST,"Documented Disabilities");
		this.selectByVisibleText(DISABILITIES_TYPE_DROPDOWN, disabilityNameStr);
		this.webEleClick(FUNCTIONAL_LIMITATIONS);
		
		List<WebElement> listofRows=this.ListEleReturn(FUNCTIONAL_LIMITATIONS_ROWS);
		for (WebElement list : listofRows) {
			this.FLClick(list.getText(),FL1Str,FL2Str, FL3Str,"Self-Care");
			this.FLClick(list.getText(),FL1Str,FL2Str, FL3Str,"Learning");
			this.FLClick(list.getText(),FL1Str,FL2Str, FL3Str,"Self-direction");
			this.FLClick(list.getText(),FL1Str,FL2Str, FL3Str,"Mobility");
			this.FLClick(list.getText(),FL1Str,FL2Str, FL3Str,"Economic Self-Sufficiency");
			this.FLClick(list.getText(),FL1Str,FL2Str, FL3Str,"Capacity for Independent Living");
			this.FLClick(list.getText(),FL1Str,FL2Str, FL3Str,"Receptive and Expressive Language");
		}
		
		this.webEleClick(ASSIGN_TO_DIAGNOSIS);
		this.threadWait();
		
		return driver;
		
	}
	
	public WebDriver evaluation_Report_Steps(String ERFirstNameStr, String ERTitleStr, String typeOfEvaluationStr) {
		
		this.webEleClick(EVALUATION_REPORT);
		this.threadWait();
		this.sendWebElements(ER_FIRSTNAME, ERFirstNameStr);
		this.sendWebElements(ER_TITLE, ERTitleStr);
		this.threadWait();
		this.evaluationType(typeOfEvaluationStr,"Psychological or Psycho-educational");
		this.evaluationType(typeOfEvaluationStr,"Neurological");
		this.evaluationType(typeOfEvaluationStr,"Psychiatric");
		this.evaluationType(typeOfEvaluationStr,"Developmental");
		this.evaluationType(typeOfEvaluationStr,"Physician");
		
		Select se = new Select(ER_TITLE_DROPDOWN);
		 if (typeOfEvaluationStr.equalsIgnoreCase("Other (please specify)")) {
				se.selectByValue("0");}
		
		this.webEleClick(ER_TITLE_DATEREPORT);
		this.webEleClick(ER_TODAY);
		this.webEleClick(ER_SAVE);
		
		return driver;
	}
	
	public WebDriver etiologySteps( String etiologyNameStr) {
		
		this.webEleClick(ETIOLOGY_SELECT);
		this.threadWait();
		
		String winHandleBefore = driver.getWindowHandle();
		for(String winHandle : driver.getWindowHandles()){
		    driver.switchTo().window(winHandle);
		}
		
		this.windowMaximize();
		this.threadWait();
		driver.findElement(By.xpath("//label[contains(text(),'"+ etiologyNameStr + "')]//parent::td/input")).click();
		this.threadWait();
		this.webEleClick(EIOLOGY_ASSIGN);
		driver.switchTo().window(winHandleBefore);
		this.threadWait();
		this.webEleClick(EIOLOGY_FINALSAVE);
		this.threadWait();
		this.webEleClick(CONSUMER_MAIN_MENU);
		this.threadWait();
		
		return driver;
	}
}
