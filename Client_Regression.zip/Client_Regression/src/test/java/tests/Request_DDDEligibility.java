package tests;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import dataProviders.DataProvider_IN_OUT;
import pages.ClientApplication_Page;
import pages.Login_Page;
import steps.NavigateToURL;

public class Request_DDDEligibility {
	public WebDriver driver;

	NavigateToURL urlNav= new NavigateToURL(driver);
	Login_Page lp;
	ClientApplication_Page clinetApp;
	
	
	@Test(dataProvider = "ReadVariant", dataProviderClass = DataProvider_IN_OUT.class)
	public void Test_DDDEligibility() {
		
		
		driver=this.urlNav.getAppURL();
		
		
		
		
		
		
		
		
		
	}
}
